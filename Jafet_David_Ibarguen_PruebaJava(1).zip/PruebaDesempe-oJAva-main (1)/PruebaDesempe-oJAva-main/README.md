(https://github.com/BUKODONOZOR/PruebaDesempe-oJAva
![Screenshot from 2024-08-05 21-35-15](https://github.com/user-attachments/assets/bec60faa-5046-40f5-8984-5536991d7fe7)
